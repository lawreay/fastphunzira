<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Core\Database;
use App\Core\Env;
use App\Core\Session;
use App\Controllers\CourseController;
use App\Repositories\AuditLogRepository;
use App\Repositories\CertificateRepository;
use App\Repositories\CertificateVerificationAttemptRepository;
use App\Repositories\InMemoryCertificateVerificationAttemptRepository;
use App\Repositories\CourseModuleRepository;
use App\Repositories\CourseRepository;
use App\Repositories\EnrollmentRepository;
use App\Repositories\ExamAttemptRepository;
use App\Repositories\ExamRepository;
use App\Repositories\InMemoryAuditLogRepository;
use App\Repositories\InMemoryCertificateRepository;
use App\Repositories\InMemoryExamAttemptRepository;
use App\Repositories\InMemoryExamRepository;
use App\Repositories\InMemoryCourseModuleRepository;
use App\Repositories\InMemoryEnrollmentRepository;
use App\Repositories\InMemoryLessonProgressRepository;
use App\Repositories\InMemoryLessonRepository;
use App\Repositories\InMemoryLoginHistoryRepository;
use App\Repositories\InMemoryUserRepository;
use App\Repositories\LessonProgressRepository;
use App\Repositories\LessonRepository;
use App\Repositories\LessonMaterialRepository;
use App\Repositories\LessonBlockRepository;
use App\Repositories\InMemoryLessonBlockRepository;
use App\Repositories\InMemoryLessonMaterialRepository;
use App\Repositories\LoginHistoryRepository;
use App\Repositories\PaymentTransactionRepository;
use App\Repositories\PlatformSettingsRepository;
use App\Repositories\StudentMembershipRepository;
use App\Repositories\QuestionRepository;
use App\Repositories\QuizAttemptRepository;
use App\Repositories\QuizRepository;
use App\Repositories\UserRepository;
use App\Services\AuditLogService;
use App\Services\AuthService;
use App\Services\CertificateService;
use App\Services\CertificateVerificationRateLimitService;
use App\Services\CourseService;
use App\Services\EnrollmentLearningService;
use App\Services\ExamService;
use App\Services\LoginSecurityService;
use App\Services\LocalMediaStorage;
use App\Services\QuizService;
use App\Services\PayChanguService;

Env::load(__DIR__ . '/../.env');

$config = require __DIR__ . '/../config/app.php';
$dbConfig = require __DIR__ . '/../config/database.php';
$securityConfig = require __DIR__ . '/../config/security.php';
$paymentsConfig = require __DIR__ . '/../config/payments.php';
$mediaConfig = require __DIR__ . '/../config/media.php';

Session::start($securityConfig);

if (!function_exists('redirect_to')) {
    function redirect_to(string $path): array
    {
        return ['redirect' => base_url($path)];
    }
}

try {
    $pdo = Database::connect($dbConfig);
} catch (Throwable $e) {
    error_log('Database connection failed: ' . $e->getMessage());

    if (($config['app_env'] ?? 'local') !== 'local') {
        http_response_code(500);
        exit('Service temporarily unavailable.');
    }

    $pdo = null;
}

$userRepository = $pdo !== null ? new UserRepository($pdo) : new InMemoryUserRepository();
$auditLogRepository = $pdo !== null ? new AuditLogRepository($pdo) : new InMemoryAuditLogRepository();
$loginHistoryRepository = $pdo !== null ? new LoginHistoryRepository($pdo) : new InMemoryLoginHistoryRepository();
$platformSettingsRepository = $pdo !== null ? new PlatformSettingsRepository($pdo) : null;
$paymentTransactionRepository = $pdo !== null ? new PaymentTransactionRepository($pdo) : null;
$studentMembershipRepository = $pdo !== null ? new StudentMembershipRepository($pdo) : null;

$auditLogService = new AuditLogService($auditLogRepository);
$loginSecurityService = new LoginSecurityService(
    $loginHistoryRepository,
    $securityConfig['login_security'] ?? []
);
$authService = new AuthService($userRepository, $loginSecurityService, $auditLogService);
$payChanguService = ($platformSettingsRepository !== null && $paymentTransactionRepository !== null)
    ? new PayChanguService($paymentsConfig, $paymentTransactionRepository, $platformSettingsRepository)
    : null;

$courseRepository = $pdo !== null ? new CourseRepository($pdo) : new \App\Repositories\InMemoryCourseRepository();
$moduleRepository = $pdo !== null ? new CourseModuleRepository($pdo) : new InMemoryCourseModuleRepository();
$lessonRepository = $pdo !== null ? new LessonRepository($pdo) : new InMemoryLessonRepository();
$lessonMaterialRepository = $pdo !== null ? new LessonMaterialRepository($pdo) : new InMemoryLessonMaterialRepository();
$lessonBlockRepository = $pdo !== null ? new LessonBlockRepository($pdo) : new InMemoryLessonBlockRepository();
$mediaStorage = new LocalMediaStorage((string) ($mediaConfig['storage_path'] ?? (dirname(__DIR__) . '/storage/learning-media')));
$enrollmentRepository = $pdo !== null ? new EnrollmentRepository($pdo) : new InMemoryEnrollmentRepository();
$progressRepository = $pdo !== null ? new LessonProgressRepository($pdo) : new InMemoryLessonProgressRepository();
$quizRepository = $pdo !== null ? new QuizRepository($pdo) : new \App\Repositories\InMemoryQuizRepository();
$questionRepository = $pdo !== null ? new QuestionRepository($pdo) : new \App\Repositories\InMemoryQuestionRepository();
$quizAttemptRepository = $pdo !== null ? new QuizAttemptRepository($pdo) : new \App\Repositories\InMemoryQuizAttemptRepository();
$examRepository = $pdo !== null ? new ExamRepository($pdo) : new InMemoryExamRepository();
$examAttemptRepository = $pdo !== null ? new ExamAttemptRepository($pdo) : new InMemoryExamAttemptRepository();
$certificateRepository = $pdo !== null ? new CertificateRepository($pdo) : new InMemoryCertificateRepository();
$certificateVerificationRepository = $pdo !== null ? new CertificateVerificationAttemptRepository($pdo) : new InMemoryCertificateVerificationAttemptRepository();
$certificateVerificationRateLimitService = new CertificateVerificationRateLimitService(
    $certificateVerificationRepository,
    $securityConfig['certificate_verification'] ?? []
);
$courseService = new CourseService($courseRepository);
$courseController = new CourseController(
    $courseService,
    $studentMembershipRepository,
    $enrollmentRepository,
    $moduleRepository,
    $quizRepository,
    $examRepository,
    $lessonRepository
);
$quizService = new QuizService(
    $courseRepository,
    $enrollmentRepository,
    $quizRepository,
    $questionRepository,
    $quizAttemptRepository,
    $studentMembershipRepository
);
$examService = new ExamService(
    $courseRepository,
    $enrollmentRepository,
    $examRepository,
    $questionRepository,
    $examAttemptRepository,
    $studentMembershipRepository
);
$certificateService = new CertificateService(
    $courseRepository,
    $enrollmentRepository,
    $examRepository,
    $examAttemptRepository,
    $certificateRepository,
    $auditLogService
);
$enrollmentLearningService = new EnrollmentLearningService(
    $courseRepository,
    $enrollmentRepository,
    $moduleRepository,
    $lessonRepository,
    $progressRepository,
    $studentMembershipRepository
);

return [
    'config' => $config,
    'db' => $pdo,
    'security' => $securityConfig,
    'payments' => $paymentsConfig,
    'media' => $mediaConfig,
    'lessonMaterialRepository' => $lessonMaterialRepository,
    'lessonBlockRepository' => $lessonBlockRepository,
    'mediaStorage' => $mediaStorage,
    'platformSettingsRepository' => $platformSettingsRepository,
    'paymentTransactionRepository' => $paymentTransactionRepository,
    'studentMembershipRepository' => $studentMembershipRepository,
    'payChanguService' => $payChanguService,
    'auth' => $authService,
    'courseService' => $courseService,
    'courseController' => $courseController,
    'courseRepository' => $courseRepository,
    'moduleRepository' => $moduleRepository,
    'lessonRepository' => $lessonRepository,
    'enrollmentRepository' => $enrollmentRepository,
    'progressRepository' => $progressRepository,
    'enrollmentLearningService' => $enrollmentLearningService,
    'quizRepository' => $quizRepository,
    'questionRepository' => $questionRepository,
    'quizAttemptRepository' => $quizAttemptRepository,
    'quizService' => $quizService,
    'examRepository' => $examRepository,
    'examAttemptRepository' => $examAttemptRepository,
    'examService' => $examService,
    'auditLogRepository' => $auditLogRepository,
    'auditLogService' => $auditLogService,
    'loginHistoryRepository' => $loginHistoryRepository,
    'loginSecurityService' => $loginSecurityService,
    'certificateRepository' => $certificateRepository,
    'certificateService' => $certificateService,
    'certificateVerificationRateLimitService' => $certificateVerificationRateLimitService,
];
